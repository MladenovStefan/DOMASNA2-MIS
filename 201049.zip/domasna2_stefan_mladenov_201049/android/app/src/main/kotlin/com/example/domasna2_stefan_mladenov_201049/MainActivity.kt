package com.example.domasna2_stefan_mladenov_201049

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
